from django.apps import AppConfig


class KitchenConfig(AppConfig):
    name = 'kitchen'
