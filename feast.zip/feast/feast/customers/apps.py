from django.apps import AppConfig


class CustomersConfig(AppConfig):
    name = 'customers'
